rootProject.name = "clicker"
